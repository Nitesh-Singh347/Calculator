/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculator;

/**
 *
 * @author Admin
 */
public class Calculator {

    public static void main(String[] args) {
        Calc ob = new Calc();
        ob.setVisible(true);
    }
}
